<?php

use App\Actions\HomePage;
use App\Actions\HomePageGraphs;
use App\Actions\Login;
use App\Http\Controllers\ClassRoomController;
use App\Http\Controllers\EntranceController;
use App\Http\Controllers\ProfilesController;
use App\Http\Controllers\QuestionsController;
use App\Http\Controllers\StudentsController;
use App\Http\Controllers\MembershipsController;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| is assigned the "api" middleware group. Enjoy building your API!
|
*/
Route::post('login', Login::class);

Route::middleware('auth:sanctum')->get('/user', function (Request $request) {
    return $request->user();
});

Route::group(['middleware' => 'auth:sanctum'], function () {
    Route::Resource('memberships', MembershipsController::class);
    //----------------------------------------------------------------------------------
    Route::Resource('profiles', ProfilesController::class);
    Route::group(['prefix' => 'profiles/{profile}'], function () {
        Route::post('membership', [ProfilesController::class, 'addMembership']);
        Route::delete('membership/{membership}', [ProfilesController::class, 'deleteMembership']);
    });
    Route::group(['prefix' => 'entrance'], function () {
        Route::get('', [EntranceController::class, 'index']);
        Route::post('fetch-profile', [EntranceController::class, 'fetchProfile']);
    });
    Route::group(['prefix' => 'questions'], function () {
        Route::get('', [QuestionsController::class, 'index']);
        Route::post('answer', [QuestionsController::class, 'answer']);
    });

});
Route::post('entrance/login', [EntranceController::class, 'login']);
