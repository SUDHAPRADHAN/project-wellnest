<?php

namespace Database\Seeders;

;

use App\Models\Profile;
use App\Models\Question;
use App\Models\User;
use Illuminate\Database\Seeder;

class FirstSeeder extends Seeder
{
    public function run()
    {
        if ((User::count() === 0)) {
            User::factory()->create(['email' => 'email@email.com']);
        }
        Profile::factory()->count(10)->create();
        $questions = [
            ['question' => 'Has your doctor said you have a heart condition?',],
            ['question' => 'Has a doctor said only do doctor recommended exercise?',],
            ['question' => 'Do you feel pain in your chest when you exercise?',],
            ['question' => 'In the past month, have you had chest pain while exercising?',],
            ['question' => 'Do you lose balance because of dizziness?',],
            ['question' => 'Do you ever lose consciousness?',],
            ['question' => 'Do you have a bone or joint problem?',],
            ['question' => 'If yes, could it be made worse by exercising?',],
            ['question' => 'Are you taking medication for blood pressure?',],
            ['question' => 'Are you taking medication for a heart condition?',],
            ['question' => 'Do you know of any reason you shouldn\'t exercise?',],
        ];
        foreach ($questions as $question) {
            Question::create($question);
        }
    }
}
