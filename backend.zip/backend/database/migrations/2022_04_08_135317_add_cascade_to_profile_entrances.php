<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class AddCascadeToProfileEntrances extends Migration
{
	public function up()
	{
		Schema::table('profile_entrances', function (Blueprint $table) {
            $table->dropForeign('profile_entrances_profile_id_foreign');
            $table->foreign('profile_id')->references('id')->on('profiles')->onDelete('cascade');

        });
	}

	public function down()
	{
		Schema::table('profile_entrances', function (Blueprint $table) {
			//
		});
	}
}
