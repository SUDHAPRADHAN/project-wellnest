<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateMembershipProfileTable extends Migration
{
	public function up()
	{
		Schema::create('membership_profile', function (Blueprint $table) {
            $table->foreignId('profile_id')->references('id')->on('profiles')
                ->cascadeOnUpdate()->cascadeOnDelete();

            $table->foreignId('membership_id')->references('id')->on('memberships')
                ->cascadeOnUpdate()->cascadeOnDelete();
		});
	}

	public function down()
	{
		Schema::dropIfExists('membership_profile');
	}
}
