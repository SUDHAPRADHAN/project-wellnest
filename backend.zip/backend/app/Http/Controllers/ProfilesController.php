<?php

namespace App\Http\Controllers;

use App\Http\Requests\Professors\AddMembershipRequest;
use App\Http\Requests\StoreProfileRequest;
use App\Http\Requests\UpdateProfileRequest;
use App\Http\Resources\ProfileResource;
use App\Models\Profile;
use App\Models\Membership;
use App\Services\GenerateUniqueCode;

class ProfilesController extends Controller
{
    public function index()
    {
        if (request()->has('paginate') && !request()->boolean('paginate')) {
            return ProfileResource::collection(Profile::get());
        }
        return ProfileResource::collection(Profile::paginate());
    }

    public function store(StoreProfileRequest $request)
    {
        $profile = Profile::create($request->validated());
        return new ProfileResource($profile);
    }

    public function show(Profile $profile)
    {
        return new ProfileResource($profile->load(['memberships', 'profileEntrances' , 'answers.question']));
    }

    public function update(UpdateProfileRequest $request, Profile $profile)
    {
        $profile->update($request->validated());
        return new ProfileResource($profile->load(['memberships', 'profileEntrances' , 'answers.question']));
    }

    public function destroy(Profile $profile)
    {
        $profile->delete();
        return new ProfileResource($profile);
    }

    public function addMembership(AddMembershipRequest $request, Profile $profile)
    {
        $profile->memberships()->detach();
        $profile->memberships()->attach($request->membership_id, [
            'expires_at' => now()->addMonths(6),
            'payment_method' => $request->payment_method,
        ]);

        $profile->load(['memberships']);
        return new ProfileResource($profile);
    }

    public function deleteMembership(Profile $profile, Membership $membership)
    {
        $profile->memberships()->detach($membership);
        $profile->load(['memberships']);
        return new ProfileResource($profile);
    }
}
