<?php

namespace App\Http\Controllers;

use App\Http\Resources\ProfileEntranceResource;
use App\Http\Resources\ProfileResource;
use App\Models\Profile;
use App\Models\ProfileEntrance;
use App\Models\User;

class EntranceController extends Controller
{
    public function login()
    {
        request()->validate([
            'email' => 'required|email',
            'password' => 'required',
        ]);
        $profile = Profile::where('email', request()->email)
            ->first();
        abort_if(request()->password !== optional($profile)->password, 400, 'wrong email or password');

        return response()->json([
            'student_id' => $profile->code,
        ]);
    }

    public function fetchProfile()
    {
        request()->validate([
            'student_id' => 'required',
        ]);
        $profile = Profile::query()
            ->where('code', request()->student_id)
            ->first();
        abort_if(!$profile, 400, 'wrong code');
        $profile->profileEntrances()->create();
        $profile->load(['memberships', 'profileEntrances' , 'answers.question']);

        return new ProfileResource($profile);
    }

    public function index()
    {
        return ProfileEntranceResource::collection(ProfileEntrance::with('profile')->orderByDesc('created_at')->get());
    }
}
