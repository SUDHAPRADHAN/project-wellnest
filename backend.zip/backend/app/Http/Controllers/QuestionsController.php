<?php

namespace App\Http\Controllers;

use App\Http\Requests\AnswerRequest;
use App\Http\Resources\ProfileResource;
use App\Http\Resources\QuestionResource;
use App\Models\Answer;
use App\Models\Profile;
use App\Models\Question;

class QuestionsController extends Controller
{
    public function index()
    {
        return QuestionResource::collection(Question::get());
    }

    public function answer(AnswerRequest $request)
    {
        $profile = Profile::findOrFail($request->profile_id);
        $answers = [];
        foreach ($request->answers as $answer) {
            $profile->answers()->updateOrCreate([
                'question_id' => $answer['question_id'],
            ], [
                'answer' => $answer['answer'],
            ]);
        }

        $profile->load('answers.question');
        return new ProfileResource($profile);
    }
}
