<?php

namespace App\Http\Controllers;

use App\Http\Requests\MembershipStoreRequest;
use App\Http\Requests\MembershipUpdateRequest;
use App\Http\Resources\MembershipResource;
use App\Models\Membership;

class MembershipsController extends Controller
{
    public function index()
    {
        return MembershipResource::collection(Membership::all());
    }

    public function store(MembershipStoreRequest $request)
    {
        $subject = Membership::Create($request->validated());
        return new MembershipResource($subject);
    }

    public function show(Membership $membership)
    {
        return new MembershipResource($membership->load(['profiles']));
    }

    public function update(MembershipUpdateRequest $request, Membership $membership)
    {
        $membership->update(array_filter($request->validated()));
        return new MembershipResource($membership);
    }

    public function destroy(Membership $membership)
    {
        $membership->delete();
        return new MembershipResource($membership);
    }
}
