<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class UpdateProfileRequest extends FormRequest
{
    public function rules(): array
    {
        return [
            'name' => ['nullable',],
            'email' => ['nullable', 'email', 'unique:users,email,' . $this->profile->id],
            'password' => ['nullable', 'min:6'],
            'phone' => ['nullable',],
            'gender' => ['nullable',],
            'birth_date' => ['nullable',],
            'special_needs' => ['nullable',],
            'photo' => ['nullable', 'image'],

        ];
    }

    public function authorize(): bool
    {
        return true;
    }

    protected function prepareForValidation()
    {
        $this->merge([
            'code' => $this->student_id ?? null,
        ]);
    }
}
