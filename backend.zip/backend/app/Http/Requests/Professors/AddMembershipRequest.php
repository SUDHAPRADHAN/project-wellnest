<?php

namespace App\Http\Requests\Professors;

use Illuminate\Foundation\Http\FormRequest;

class AddMembershipRequest extends FormRequest
{
    public function rules()
    {
        return [
            'membership_id' => ['required', 'exists:memberships,id'],
            'payment_method' => ['required'],
        ];
    }

    public function authorize()
    {
        return true;
    }
}
