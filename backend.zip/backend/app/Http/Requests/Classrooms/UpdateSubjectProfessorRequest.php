<?php

namespace App\Http\Requests\Classrooms;

use Illuminate\Foundation\Http\FormRequest;

class UpdateSubjectProfessorRequest extends FormRequest
{
    public function rules()
    {
        return [
            'professor_id' => ['exists:professors,id'],
            'subject_id' => ['exists:subjects,id'],
        ];
    }

    public function authorize()
    {
        return true;
    }
}
