<?php

namespace App\Http\Requests\Classrooms;

use Illuminate\Foundation\Http\FormRequest;

class AddSubjectProfessorRequest extends FormRequest
{
    public function rules()
    {
        return [
            'professor_id' => ['required', 'exists:professors,id'],
            'subject_id' => ['required', 'exists:subjects,id'],
        ];
    }

    public function authorize()
    {
        return true;
    }
}
