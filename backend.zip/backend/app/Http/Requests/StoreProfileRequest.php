<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class StoreProfileRequest extends FormRequest
{
    public function rules(): array
    {
        return [
            'name' => ['required',],
            'email' => ['required', 'email', 'unique:profiles,email'],
            'phone' => ['required',],
            'password' => ['required', 'min:6'],
            'photo' => ['nullable', 'image'],
            'gender' => ['required',],
            'birth_date' => ['required',],
            'special_needs' => ['nullable',],
            'code' => ['nullable',],
        ];
    }

    public function authorize(): bool
    {
        return true;
    }
    protected function prepareForValidation()
    {
        $this->merge([
           'code' => $this->student_id ?? null,
        ]);
    }
}
