<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class AnswerRequest extends FormRequest
{
    public function rules(): array
    {
        return [
            'profile_id' => 'required|integer|exists:profiles,id',
            'answers' => 'required|array',
            'answers.*.question_id' => 'required|integer|exists:questions,id',
            'answers.*.answer' => 'required',
        ];
    }

    public function authorize(): bool
    {
        return true;
    }
}
