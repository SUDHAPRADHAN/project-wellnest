<?php

namespace App\Http\Resources;

use App\Models\Profile;
use Illuminate\Http\Request;
use Illuminate\Http\Resources\Json\JsonResource;

/** @mixin Profile */
class ProfileResource extends JsonResource
{
    /**
     * @param Request $request
     * @return array
     */
    public function toArray($request)
    {
        return [
            'id' => $this->id,
            'name' => $this->name,
            'phone' => $this->phone,
            'student_id' => $this->code,
            'gender' => $this->gender,
            'birth_date' => $this->birth_date,
            'special_needs' => $this->special_needs,
            'password' => $this->password,
            'email' => $this->email,
            'created_at' => $this->created_at,
            'updated_at' => $this->updated_at,

            'memberships' => MembershipResource::collection($this->whenLoaded('memberships')),
            'answers' => AnswerResource::collection($this->whenLoaded('answers')),
            'profile_entrances' => ProfileEntranceResource::collection($this->whenLoaded('profileEntrances')),
        ];
    }
}
