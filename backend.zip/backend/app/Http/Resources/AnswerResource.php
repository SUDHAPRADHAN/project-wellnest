<?php

namespace App\Http\Resources;

use Illuminate\Http\Request;
use Illuminate\Http\Resources\Json\JsonResource;

/** @mixin \App\Models\Answer */
class AnswerResource extends JsonResource
{
    /**
     * @param Request $request
     * @return array
     */
    public function toArray($request)
    {
        return [
            'id' => $this->id,
            'answer' => $this->answer,
            'created_at' => $this->created_at,

            'profile' => new ProfileResource($this->whenLoaded('profile')),
            'question' => new QuestionResource($this->whenLoaded('question')),
        ];
    }
}
