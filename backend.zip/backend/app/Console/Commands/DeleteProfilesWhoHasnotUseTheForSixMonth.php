<?php

namespace App\Console\Commands;

use App\Models\Profile;
use Illuminate\Console\Command;

class DeleteProfilesWhoHasnotUseTheForSixMonth extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'delete:expired';
    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'this command will automatically delete the profiles who has not use the app for six month';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Execute the console command.
     *
     * @return int
     */
    public function handle()
    {
        $profiles = Profile::query()
            ->with('profileEntrances')
            ->get();

        $profiles = $profiles->filter(function ($p) {
            $lastVisit = $p
                ->profileEntrances()
                ->orderBy('created_at', 'desc')
                ->first();

            if ($lastVisit && $lastVisit->created_at->diffInMonths(now()) >= 6) {
                return true;
            }
            return false;
        });

        foreach ($profiles as $profile) {
            $profile->delete();
        }
        return 0;
    }
}
