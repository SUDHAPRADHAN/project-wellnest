<?php

namespace App\Actions;

use App\Models\User;
use Hash;
use Illuminate\Support\Facades\DB;
use Lorisleiva\Actions\Action;

class Login extends Action
{
    public function authorize()
    {
        return true;
    }

    public function rules()
    {
        return [
            'email' => ['required', 'email'],
            'password' => ['required'],
        ];
    }

    public function handle()
    {

        $user = User::where('email', request()->email)
            ->first();
//        dd(User::get());

        abort_if(!$user || !Hash::check(request()->password, $user->password), 400, 'wrong email or password');
        $token = $user->createToken($user->email, ['user'])->plainTextToken;
        return response()->json([
            'message' => 'success',
            'token' => $token,
        ]);
    }
}
